# MVC Template Sample



## 
# mvc_template

An MVC Project Template with Sample Apps

