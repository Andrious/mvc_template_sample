## 1.4.0
 May 18, 2020
- Class Item renamed DataFieldItem
- mvc_application: ^5.0.0

## 1.3.1
 May 15, 2020
- get title in Contact.dart; ContactDetailsPage use Contact(); 

## 1.3.0
 May 12, 2020
- Replace con.setBuild(); with con.refresh(); _street = street; con.title; con = AppCon();

## 1.2.0
 May 11, 2020
- Reformat listing code into include getters.

## 1.1.0
 May 06, 2020
- ContactListState() : super(Contact()) {
- model.dart import file reformatted.

## 0.1.0
 May 02, 2020
- Initial Commit
